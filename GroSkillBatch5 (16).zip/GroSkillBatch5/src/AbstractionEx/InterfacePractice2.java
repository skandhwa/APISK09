package AbstractionEx;

interface I15
{
	void test();
}

class C20 
{
	void display()
	{
		System.out.println("Hello");
	}
}


class C21 extends C20 implements I15
{
	public void test()
	{
		System.out.println("Hello How r u");
	}
}



public class InterfacePractice2 {

	public static void main(String[] args) {
		

	}

}
