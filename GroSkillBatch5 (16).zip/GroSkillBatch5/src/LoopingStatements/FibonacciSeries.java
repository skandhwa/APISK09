package LoopingStatements;

public class FibonacciSeries {

	public static void main(String[] args) {
		
		int count=15;
		
		int n1=0;//n1=0
		int n2=1;
		
		System.out.println("Fibonacci series is  ");
		
		System.out.print(n1+" "+n2);/// 0 ..1
		
		for(int i=2; i<=count;i++)/// i=2, 2<=7// i=3,3<=7
		{
			
			int n3=n1+n2;///n3= 0+1=1 //n3=1+1=2
			
			n1=n2;///n1=1//n1=1
			n2=n3;//n2=1//n2=2
			System.out.print(" "+n3);
			
		}

	}

}
