package LoopingStatements;

public class forLoopEx {

	public static void main(String[] args) {
		
		for(int i=0;i<=5;i++)////i=0,0<=5///1<=5//2<=5.....6<=5
		{
			System.out.println(i);///0///1///2
			
			///0++///1++//2++//5++//// o(n)
		}
		

	}

}
