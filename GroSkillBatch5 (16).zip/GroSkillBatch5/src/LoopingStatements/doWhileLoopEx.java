package LoopingStatements;

public class doWhileLoopEx {

	public static void main(String[] args) {
		
		int i=5;
		do
		{
			System.out.println(i);///5//6//7///8
			i++;//5++//6++//7++///8++
		}
		
		while(i<=8);///6<=8///7<=8///8<=8///9<=8
		
		

	}

}
