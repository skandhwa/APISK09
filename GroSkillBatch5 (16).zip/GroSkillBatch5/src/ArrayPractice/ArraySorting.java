package ArrayPractice;

public class ArraySorting {

	public static void main(String[] args) {
		
		int []a= {95,12,17,2,1};
		
		System.out.println("Sorted Array is: ");
		
		for(int i=0;i<a.length;i++)//i=0,0<5//i=1,1<5
		{
			for(int j=i+1;j<a.length;j++)//j=4,4<5
			{
				if(a[i]>a[j])// 
				{
					int temp=a[i];///
					a[i]=a[j];///
					a[j]=temp;//
				}
			}
			
			System.out.print(a[i]+"  ");
			
		}
		
		
		
		
	

	}

}
