package ArrayPractice;

import java.util.Scanner;

public class SearchAnElementArray {

	public static void main(String[] args) {
		
		 int[] arr = {10, 25, 30, 45, 60, 75};
	        Scanner sc = new Scanner(System.in);

	        System.out.print("Enter the key to search: ");
	        int key = sc.nextInt();

	        boolean flag = false;

	        for (int i = 0; i < arr.length; i++) {
	            if (arr[i] == key) {
	                System.out.println("Element found at index: " + i);
	                flag = true;
	                break;
	            }
	        }

	        if (!flag) {
	            System.out.println("Element not found");
	        }

	        sc.close();
		
		
		

	}

}
