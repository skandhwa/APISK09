package CollectionsEx;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyofArray {

	public static void main(String[] args) {
		
		
		int []a= {10,20,30,10,20,10};
		Map<Integer,Integer>mp=new LinkedHashMap<Integer,Integer>();
		for(int x:a)
		{
			if(mp.containsKey(x))
			{
				mp.put(x, (mp.get(x)+1)); /// mp.put(10,2)//mp.put(20,2)//mp.put(10,3)
			}
			else
			{	
				mp.put(x,1);
			}
		}
		
		for(Map.Entry y:mp.entrySet())
		{
			System.out.println(y.getKey()+"  "+y.getValue());
		}
		
		int maxFreq=0;
		int minFreq=9999;
		int maxElement=0,minElement=0;
		
		for(Map.Entry<Integer,Integer> z:mp.entrySet())
		{
			int freq=z.getValue();//3///freq=2///freq=1
			int element=z.getKey();//10///element=20///element=30
			
			if(freq>maxFreq)///3>0///2>3///1>3
			{
				maxFreq=freq;//maxFreq=3
				maxElement=element;///maxElement=10
			}
			
			if(freq<minFreq)///3<9999///2<3//1<2
			{
				minFreq=freq;//minFreq=3///minFreq=2///minFreq=1
				minElement=element;///minElement=10////minElement=20//minElement=30
			}
			
			
		}
		
		
		System.out.println("Maximum Frequency is   "+maxElement   +"-->"+maxFreq);
		System.out.println("Minimum Frequency is   "+minElement   +"-->"+minFreq);
		
		
		
		
		
		
		
		
		
		

	}

}
