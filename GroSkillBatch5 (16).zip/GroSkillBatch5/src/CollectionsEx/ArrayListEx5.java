package CollectionsEx;

import java.util.ArrayList;
import java.util.List;

public class ArrayListEx5 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("apple");
		li.add("guava");
		li.add("orange");
		li.add("grapes");
		
	Object[]arr=	li.toArray();
	
	for(Object x:arr )
	{
		System.out.println(x);
	}
		
	}

}
