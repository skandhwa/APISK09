package CollectionsEx;

import java.util.LinkedHashSet;
import java.util.Set;

public class SetMethods4 {

	public static void main(String[] args) {
		
		 Set<String> s1=new LinkedHashSet<String>();
			s1.add("apple");
			s1.add("guava");
			s1.add("orange");
			s1.add("grapes");
			
			Set<String> s2=new LinkedHashSet<String>();
			s2.add("apple");
			s2.add("guava");
			s2.add("melon");
			s2.add("banana");
			
			s2.removeAll(s1);
			
			System.out.println(s2);
		

	}

}
