package MyPkg1;

public class AssignmentOperatorEx {

	public static void main(String[] args) {
		
		
		int a=10;
		
		a-=5; //a=a+20;
		
		System.out.println(a);
		
		

	}

}
