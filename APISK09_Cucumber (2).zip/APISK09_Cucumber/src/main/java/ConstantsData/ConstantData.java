package ConstantsData;

public class ConstantData {
	
	public static final String PROP_FILE_PATH="src/main/java/Global.properties";
	public static final String EXCEL_PATH="E:/TestData11thFeb.xlsx";
	public static final String SHEET_NAME="Sheet1";

}



