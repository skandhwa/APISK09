package POJOEx2;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CreateEmployee2 {

	public static void main(String[] args) throws JsonProcessingException {
		
		EmployeeAddress x=new EmployeeAddress();
		x.setCity("Delhi");
		x.setStreet("MG road");
		x.setZipcode(654321);
		
		
		EmployeePOJO2 emp=new EmployeePOJO2();
		
		emp.setName("Max");
		emp.setId(5678);
		emp.setSalary(76000f);
		emp.setMarried(false);
		emp.setEmpAddress(x);
		
		ObjectMapper obj=new ObjectMapper();
		
	String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
		
		
		
		

	}

}
