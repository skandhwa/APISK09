package MyPractice;

class Vehicle
{
	final int speed=40;
	
	void run()
	{
		speed=50;
		System.out.println("speed is  "+speed);
	}
	
}



public class FinalKeyword1 {

	public static void main(String[] args) {
		
		Vehicle obj=new Vehicle();
		obj.run();

	}

}
