package MyPractice;

class Animal
{
	String colour="red";
	void run()
	{
		System.out.println("Animal runs");
	}
}

class Dog extends Animal
{
	String colour="blue";
	void run()
	{
		System.out.println("Dog runs");
	}
	void message()
	{
		System.out.println("Hello");
	}
	void display()
	{
		System.out.println("How r u");
	}
	
	void show()
	{
		run();
		message();
		display();
		super.run();
		System.out.println(colour);
		System.out.println(super.colour);
	}
	
	
	
	
}


public class superEx1 {

	public static void main(String[] args) {
		
		Dog obj=new Dog();
		obj.show();
		

	}

}
