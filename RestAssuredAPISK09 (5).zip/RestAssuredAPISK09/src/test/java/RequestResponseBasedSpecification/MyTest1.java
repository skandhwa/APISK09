package RequestResponseBasedSpecification;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

import static io.restassured.RestAssured.*;

import PayloadData.Payload;

public class MyTest1 {

	public static void main(String[] args) {
		
		RequestSpecification req=new RequestSpecBuilder().
				setBaseUri("https://reqres.in")
				.setContentType(ContentType.JSON)
				.setRelaxedHTTPSValidation().
				addHeader("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
				.build();
		
		RequestSpecification req1=given().log().all().spec(req).body(Payload.addEmployeeDetails("Tom","Manager"));
		
		ResponseSpecification res=new ResponseSpecBuilder().
				expectStatusCode(201).expectContentType(ContentType.JSON)
				.build();
		
	String Response=	req1.when().post("api/users").then().spec(res).extract().response()
		.asString();
	
	System.out.println(Response);
		
		
		
		

	}

}
