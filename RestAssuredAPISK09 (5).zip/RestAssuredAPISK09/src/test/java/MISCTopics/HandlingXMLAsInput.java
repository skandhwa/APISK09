package MISCTopics;

import static io.restassured.RestAssured.given;

import PayloadData.Payload;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class HandlingXMLAsInput {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://petstore.swagger.io";
		
		 String res=		given().log().all().
				
				headers("content-type","application/xml").
				body(Payload.addPet()).
				
				
				
				when().post("v2/pet").
			    then().log().all().assertThat().statusCode(200)
			    .extract().response().asString();
		 
		 System.out.println(res);
		

	}

}
