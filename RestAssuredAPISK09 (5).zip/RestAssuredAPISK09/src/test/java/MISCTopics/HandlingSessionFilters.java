package MISCTopics;

import static io.restassured.RestAssured.given;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import PayloadData.Payload;
import io.restassured.RestAssured;
import io.restassured.filter.session.SessionFilter;
import io.restassured.response.Response;

public class HandlingSessionFilters {

	SessionFilter s;
	
	@BeforeTest
	public SessionFilter captureSessionId()
	{
		s=new SessionFilter();
		return s;
	}
	
	@Test
	public void myTest1()
	{
		RestAssured.baseURI="https://reqres.in";
		
		 String Response=		given().log().all().filter(s).
				headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
				headers("content-type","application/json").
				when().get("api/users/2").
			    then().log().all().extract().response().asString();
		 
		 System.out.println(Response);
		 
	}
	
	@Test
	public void myTest2()
	{
		RestAssured.baseURI="https://reqres.in";
		
		 String res=		given().log().all().filter(s).
				headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
				headers("content-type","application/json").
				body(Payload.addEmployeeDetails("harry","QA manager")).
				
				
				
				when().post("api/users").
			    then().log().all().assertThat().statusCode(201)
			    .extract().response().asString();
		 
		 System.out.println(res);
	 
	}
	
	
	
}
