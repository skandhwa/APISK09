package RequestResponseSpecification2;

public class getEmployee2 {

	public static void main(String[] args) {
		
		
		String Response=	ReUse.getReq().when().get("api/users")
				.then().log().all().
				spec(ReUse.getRes(200))
				.extract().response().asString();
			
			
			System.out.println(Response);
				

	}

}
