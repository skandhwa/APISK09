package MyPractice1;

import static io.restassured.RestAssured.given;

import org.testng.Assert;

import PayloadData.Payload;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class LibraryAPIExample {

	public static void main(String[] args) {
		
		RestAssured.baseURI="http://216.10.245.166";
		
		String isbn="" + (char)('a' + Math.random()*26) + (char)('a' + Math.random()*26) + (char)('a' + Math.random()*26);
		String aisle=String.valueOf((int)(Math.random() * 900) + 100);
        
		String actualBookId=isbn+aisle;
		
	
	String Response=	given().log().all().headers("content-type","application/json")
		.body(Payload.addBook(isbn, aisle))
		.when().post("Library/Addbook.php")
		
		.then().log().all().assertThat().statusCode(200)
		.extract().response().asString();
	
	
	System.out.println(Response);
	
	
	JsonPath js=new JsonPath(Response);
	String expectedBookId=js.get("ID");
	
	String message=js.getString("Msg");
	
	Assert.assertEquals(actualBookId, expectedBookId);
	
	Assert.assertEquals("successfully added", message);
	
	String expectedID=isbn+aisle;
	
	String actual_ID=js.getString("ID");
	
	Assert.assertEquals(actual_ID, expectedID);
	
	System.out.println("My Test case passed");
	
	
	
	
	
		
		
		
		

	}

}
