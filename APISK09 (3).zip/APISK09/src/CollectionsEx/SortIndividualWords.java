package CollectionsEx;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class SortIndividualWords {

	public static void main(String[] args) {
		
		String str="tip tap toe";
		
		String []s1= str.split(" ");
		
		
		
		StringBuilder sb=new StringBuilder();
		for(String x:s1)
		{
			
			List<Character> li=new ArrayList<Character>();
			
			for(char y:x.toCharArray())
			{
				li.add(y);
			}
			
			Collections.sort(li);
			
			StringBuilder revword=new StringBuilder();
			for(char z:li)
			{
				revword.append(z);
			}
			
			sb.append(revword).append(" ");
			
			
		}
		
		System.out.println(sb.toString());
		
		
		

	}

}
