package CollectionsEx;

public class ReplaceMethodEx {

	public static void main(String[] args) {
		
		String str="&*^%43423abcdREDF";
		
		///abcd
		
		
		/// [0-9a-zA-Z]

		String str1= str.replaceAll("[^a-zA-Z0-9]","");
		
		System.out.println(str1);
		
		
	}

}
