package CollectionsEx;

public class RoughJava {

	public static void main(String[] args) {
		
		String str="Java";
		
	str=	str.repeat(5);
		
		System.out.println(str);
		

	}

}
