package StepDefinition14;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition14 {
	
	WebDriver driver;
	@Before(order=1)
	public void beforeTest()
	{
		System.out.println("This is before all test 1");
	}
	
	@Before(order=2)
	public void beforeTest2()
	{
		System.out.println("this is before all test 2");
	}
	
	@After
	public void afterTest()
	{
		System.out.println("This is after all test");
	}
	
	@Before("@smoke")
	public void onlyBeforeSmoke()
	{
		System.out.println("I will run only before smoke");
	}
	
	@After("@smoke")
	public void onlyAfterSmoke()
	{
		System.out.println("I will run only after smoke");
	}
	
	
	
	
	@Given("user opens the application URL in the browser")
	public void user_opens_the_application_url_in_the_browser() {
	   
		System.out.println("Application opened");
		
	}

	@Given("user enters the username")
	public void user_enters_the_username() {
		
		System.out.println("username eneterd");
	   
	}

	@Given("user enters the password")
	public void user_enters_the_password() {
	   
		System.out.println("password eneterd");
	}

	@When("user clicks on submit button")
	public void user_clicks_on_submit_button() {
		
		System.out.println("submit button clicked");
	   
	}

	@Then("user will be navigated to the homepage of the application")
	public void user_will_be_navigated_to_the_homepage_of_the_application() {
	    
		System.out.println("navigated to homepage");
	}
	
	@Given("user enters the username as {string}")
	public void user_enters_the_username_as(String string) {
		
		System.out.println("username entered");
	   
	}

	@Given("user enters the password as {string}")
	public void user_enters_the_password_as(String string) {
		
		System.out.println("password eneterd");
	   
	}
	
	@Then("user searches an item in the search box")
	public void user_searches_an_item_in_the_search_box() 
	{
	   System.out.println("search successfull");
	}

	@Then("user clicks on enter")
	public void user_clicks_on_enter() 
	{
		System.out.println("enter clicked");
	}

	@Then("list of products are displayed")
	public void list_of_products_are_displayed() 
	{
		System.out.println("product list displayed");
	}

	@Then("user can select one product and add it to cart")
	public void user_can_select_one_product_and_add_it_to_cart() 
	{
		System.out.println("one item searched");
	}
	
	
	@Then("user searches an electronic item in the search box")
	public void user_searches_an_electronic_item_in_the_search_box() {
	   
		System.out.println("electronic item search successfull");
	}

	@Then("user searches an clothing item in the search box")
	public void user_searches_an_clothing_item_in_the_search_box() {
		System.out.println("clothing item search successfull");
	    
	}

	@Then("user searches an lifestyle item in the search box")
	public void user_searches_an_lifestyle_item_in_the_search_box() {
		
		System.out.println("lifestyle item search successfull");
	    
	}
	
	
	@Given("user opens up the application website")
	public void user_opens_up_the_application_website() {
	   
	}

	@Given("user enters the details below in the format")
	public void user_enters_the_details_below(io.cucumber.datatable.DataTable userdata) {
	   
		List<List<String>> data= userdata.asLists(String.class);
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(data.get(1).get(0));
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(data.get(1).get(1));
		driver.findElement(By.xpath("//*[@rows='3']")).sendKeys(data.get(1).get(2));
		driver.findElement(By.xpath("//*[@type='email']")).sendKeys(data.get(1).get(3));
		driver.findElement(By.xpath("//*[@type='tel']")).sendKeys(data.get(1).get(4));
		
		
		
		
		
		
		
	}
	
	@Then("user proceeds for the payment gateway for processing payment")
	public void user_proceeds_for_the_payment_gateway_for_processing_payment() {
	  
		System.out.println("user proceeds for payment");
		
		
	}
	
	
	
	@Given("user opens the demo reg form")
	public void user_opens_the_demo_reg_form() {
	   
		driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		
	}

	@Given("user enters the fname is form as {string}")
	public void user_enters_the_fname_is_form_as(String firstname) {
		
		driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(firstname);
	  
	}

	@Given("user enters the lname is form as {string}")
	public void user_enters_the_lname_is_form_as(String lastname) {
	   
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(lastname);
	}

	@Given("user will enter the addresss in textarea as {string}")
	public void user_will_enter_the_addresss_in_textarea_as(String address) {
	    
		driver.findElement(By.xpath("//textarea[@ng-model='Adress']")).sendKeys(address);	
		
	}

	@Given("user will enter the emailaddresss  as {string}")
	public void user_will_enter_the_emailaddresss_as(String emailaddress) {
	 
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys(emailaddress);
		
	}

	@Given("user will enter the phone  as {string}")
	public void user_will_enter_the_phone_as(String phone) {
	   
		driver.findElement(By.xpath("//input[@type='tel']")).sendKeys(phone);
	}

	@Given("user selects the gender")
	public void user_selects_the_gender() throws InterruptedException {
	  
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@value='Male']")).click();
	}

	@Given("user also selects their hobbies")
	public void user_also_selects_their_hobbies() {
	   
		driver.findElement(By.xpath("//input[@value='Cricket']")).click();
	}

	
	
	

}
