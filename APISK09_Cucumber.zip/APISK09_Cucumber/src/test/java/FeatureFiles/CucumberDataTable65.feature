Feature: Registration Fill up form

  Scenario: Registration form fillup once
    Given user opens up the application website
    And user enters the details below in the format
      | firstname | lastname | address  | emailaddress    | phone      |
      | harry     | brook    | mjcolony | hb123@gmail.com | 9832178797 |
