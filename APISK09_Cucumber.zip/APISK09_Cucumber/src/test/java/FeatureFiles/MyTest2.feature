Feature: Validate the Search functionality


@regression1
Scenario: Validate the serach operation

    Given user opens the application URL in the browser
    And user enters the username as "saurabh"
    And user enters the password as "test224"
    When user clicks on submit button
    Then user will be navigated to the homepage of the application
    And user searches an item in the search box
    And user clicks on enter 
    Then list of products are displayed 
    Then user can select one product and add it to cart