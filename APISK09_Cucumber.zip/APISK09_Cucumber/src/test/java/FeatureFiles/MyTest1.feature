Feature: Login Scenario

@smoke
  Scenario: Validate login functionality with correct username and password
    Given user opens the application URL in the browser
    And user enters the username as "saurabh"
    And user enters the password as "test224"
    When user clicks on submit button
    Then user will be navigated to the homepage of the application

@sanity
  Scenario Outline: Validate login functionality with incorrect username and incorrect password
    Given user opens the application URL in the browser
    And user enters the username as "<username>"
    And user enters the password as "<password>"
    When user clicks on submit button
    Then user will be navigated to the homepage of the application

    Examples: 
      | username | password  |
      | abcd     | test@1234 |
      | heft     | test@3456 |
      | jhgt     | test@3459 |
      | bhgfc    | test@890  |
