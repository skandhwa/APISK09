Feature: Verify add to cart functionality

  Background: 
    Given user opens the application URL in the browser
    And user enters the username as "saurabh"
    And user enters the password as "test224"
    When user clicks on submit button
    Then user will be navigated to the homepage of the application

  Scenario: Validate adding one electronics product to cart
    And user searches an electronic item in the search box
    And user clicks on enter
    Then list of products are displayed
    Then user can select one product and add it to cart

@smoke1 @regression1 @sanity1
  Scenario: Validate adding one clothing product to cart
    And user searches an clothing item in the search box
    And user clicks on enter
    Then list of products are displayed
    Then user can select one product and add it to cart
    Then user proceeds for the payment gateway for processing payment

  Scenario: Validate adding one lifestyle product to cart
    And user searches an lifestyle item in the search box
    And user clicks on enter
    Then list of products are displayed
    Then user can select one product and add it to cart
