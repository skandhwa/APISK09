@smoke2

Feature: Validate user registration

  Scenario Outline: Check Reg Functionality of user
    Given user opens the demo reg form
    And user enters the fname is form as "<firstname>"
    And user enters the lname is form as "<lastname>"
    And user will enter the addresss in textarea as "<address>"
    And user will enter the emailaddresss  as "<emailaddress>"
    And user will enter the phone  as "<phone>"
    And user selects the gender
    And user also selects their hobbies

    Examples: 
      | firstname | lastname | address  | emailaddress  | phone      |
      | harry     | dsouza   | mg nagar | abc@gmail.com | 9832178797 |
