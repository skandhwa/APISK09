package MyPractice1;

import static io.restassured.RestAssured.given;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class MyTest3 {

	public static void main(String[] args) throws Exception {
		
		

		RestAssured.baseURI="https://reqres.in";
		
		 Response res=		given().log().all().
				headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
				queryParam("page",2).
				headers("content-type","application/json").
				when().get("api/users").
			    then().log().all().assertThat().statusCode(200)
			    .extract().response();
		 
		 
		 String Response=res.asString();
			
			JsonPath js=new JsonPath(Response);
			
		String featureVal=	js.getString("_meta.features[2]");
		
		System.out.println(featureVal);
		
		 
		 
		 
		long time= res.getTime();
		
		System.out.println(time);
		
		if(time>5000)
		{
			throw new Exception("Time limit exceeded");
		}
		else
		{
			System.out.println("Test case passed");
		}
		 
		
		
		 

	}

	}
