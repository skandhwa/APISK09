package MyPractice;

class Employee
{
	int id;
	String name;
	static String CompanyName="TCS";
	
	Employee(int id,String name)
	{
		this.id=id;
		this.name=name;
		
	}
	
	static void change()
	{
		CompanyName="CTS";
	}
	
	
	
	void display()
	{
		System.out.println(id+"  "+name+"  "+CompanyName);
	}
	
}



public class StaticVarEx {

	public static void main(String[] args) {
		
		Employee obj=new Employee(1234,"Rohan");
		Employee obj1=new Employee(7234,"Mohan");
		Employee obj2=new Employee(8765,"Sohan");
		Employee obj3=new Employee(6544,"Harish");
		Employee.change();
		obj.display();
		obj1.display();
		obj2.display();
		obj3.display();
		
		
		
		

	}

}
