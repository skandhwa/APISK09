package MyPractice;

class Bank
{
	final int getROI(int x,int y)
	{
		return x+y;
	}
}

class SBI extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}

class HDFC extends Bank
{
	void test()
	{
		System.out.println("Hi");
	}
}



public class FinalMethod {

	public static void main(String[] args) {
		
		SBI obj=new SBI();
		obj.getROI(4, 5);
		
		

	}

}
