package MyPractice;

class X
{
	static void display()
	{
		System.out.println("Hello");
	}
	
	
}


public class StaticEx {
	
	static void test()
	{
		System.out.println("Hi");
	}
	

	public static void main(String[] args) {
		
		X.display();
		test();
		
		
	}

}
