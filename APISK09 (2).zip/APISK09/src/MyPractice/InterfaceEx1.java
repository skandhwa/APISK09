package MyPractice;

interface I1
{
	int x=10;
	void test();
	void show();
	
}

class A implements I1
{
	public void test()
	{
		System.out.println("Hi");
	}
	
	public void show()
	{
		System.out.println("Hello");
	}
	
}



public class InterfaceEx1 {

	public static void main(String[] args) {
		
		I1 ref=new A();
		ref.test();
		ref.show();
		System.out.println(ref.x);
		
		
		
	}

}
