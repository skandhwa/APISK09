package CollectionsEx;

import java.util.Map;
import java.util.TreeMap;

public class TreeMapEx {

	public static void main(String[] args) {
		
		TreeMap<Integer,String> mp=new TreeMap<Integer,String>();
		
		mp.put(12,"apple");
		mp.put(2,"orange");
		mp.put(5,"mango");
		mp.put(23,"pines");
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.println(x.getKey()+"  "+x.getValue());
		}
		
		for(int y:mp.descendingKeySet())
		{
			System.out.println(y);
		}
		
		
		

	}

}
