package CollectionsEx;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyofCharacters {

	public static void main(String[] args) {
		
		String str="success";
		char []ch=str.toCharArray();
		Map<Character,Integer> mp=new LinkedHashMap<Character,Integer>();
		
		for(Character x:ch)
		{
			if(mp.containsKey(x))
			{
				mp.put(x, (mp.get(x)+1));
			}
			
			else
			{
				mp.put(x,1);
			}
		}
		
		for(Map.Entry y:mp.entrySet())

		{
			System.out.print(y.getKey()+" "+y.getValue()+"   ");
		}
		
		int maxFreq=0;
		int minFreq=99999;
		
		char maxElement='\0',minElement='\0';
		
		
		for(Map.Entry<Character,Integer> x:mp.entrySet() )
		{
			int freq=x.getValue();//
			char element=x.getKey();//
			if(freq>maxFreq)///
			{
				maxFreq=freq;//
				maxElement=element;//
				
			}
			
			if(freq<minFreq)//
			{
				minFreq=freq;///
				minElement=element;///
				
			}
			
		}
		
		System.out.println();
		System.out.println("MaximumFrequency is "+maxElement  +" -> "+maxFreq);
		System.out.println("MinimumFrequency is "+minElement  +" -> "+minFreq);
		
		
		
		
		

	}

}
