package CollectionsEx;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RotateElements {

	public static void main(String[] args) {
		
		int []a= {5,2,3,0,1};
		List<Integer> li=new ArrayList<Integer>();
		
		for(int x:a)
		{
			li.add(x);
		}
		
		Collections.rotate(li, -1);
		
		System.out.println(li);
		
		
		

	}

}
