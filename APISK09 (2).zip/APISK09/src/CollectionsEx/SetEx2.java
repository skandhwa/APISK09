package CollectionsEx;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

public class SetEx2 {

	public static void main(String[] args) {
		
		Set<String> s1=new LinkedHashSet<String>();
		s1.add("apple");
		s1.add("banana");
		s1.add("mango");
		s1.add("orange");
		
//		s1.remove("apple");
//		System.out.println(s1);
//		
//		s1.clear();
//		System.out.println(s1);
		
//	boolean flag=	s1.contains("mango");
//	System.out.println(flag);
		
		
	int x=	s1.size();
	
	System.out.println("Size of set  "+x);
	
	
		

	}

}
