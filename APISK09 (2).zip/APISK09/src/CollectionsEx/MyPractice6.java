package CollectionsEx;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MyPractice6 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("Orange");
		li.add("Mango");
		li.add("Apple");
		li.add("Banana");
		
		
		
	Object []arr=	li.toArray();
	
	//System.out.println(arr);
	
	for(Object x:arr)
	{
		System.out.println(x);
	}
	
	
	
	

	}

}
