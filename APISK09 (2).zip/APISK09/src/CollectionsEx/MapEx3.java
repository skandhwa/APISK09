package CollectionsEx;

import java.util.HashMap;
import java.util.Map;

public class MapEx3 {

	public static void main(String[] args) {
		
		
		Map<Integer,String> mp=new HashMap<Integer,String>();
		mp.put(1,"orange");
		mp.put(2,"apple");
		mp.put(3,"kiwi");
		mp.put(4,"melon");
		
	boolean flag=	mp.containsKey(30);
	
	System.out.println("Does the map contains key as 3 "+flag);
	
String str=	mp.get(2);

System.out.println(str);

boolean flag2=mp.containsValue("kiwi");

System.out.println(flag2);
		
		

	}

}
