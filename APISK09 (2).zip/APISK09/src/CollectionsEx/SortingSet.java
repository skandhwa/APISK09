package CollectionsEx;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SortingSet {

	public static void main(String[] args) {
		
		Set<Integer> s =new HashSet<Integer>();
		s.add(1134);
		s.add(1200);
		s.add(180);
		s.add(500);
		
		List<Integer> li=new ArrayList<Integer>();
		for(Integer x:s)
		{
			li.add(x);
		}
		
		Collections.sort(li);
		
		System.out.println(li);
		
//		for(Integer y:li)
//		{
//			s.add(y);
//		}
//		System.out.println("After sorting");
//		System.out.println(s);
		
		
		
		

	}

}
