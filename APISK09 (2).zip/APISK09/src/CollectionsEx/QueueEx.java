package CollectionsEx;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueEx {

	public static void main(String[] args) {
		
		Queue<Integer> q1=new PriorityQueue<Integer>();
		q1.add(5);
		q1.add(12);
		q1.add(34);
		q1.add(99);
		
		System.out.println(q1);
		
		q1.remove();
		
		System.out.println(q1);
		
		
		

	}

}
