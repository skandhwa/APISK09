package CollectionsEx;

import java.util.Vector;

public class VectorEx {

	public static void main(String[] args) {
		
		Vector<Integer> v=new Vector<Integer>();
		v.add(56);
		v.add(67);
		v.add(99);
		v.add(102);
		
		System.out.println(v);
		
		
		

	}

}
