package CollectionsEx;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MyPractice1 {

	public static void main(String[] args) {
		
		List<Integer> li =new ArrayList<Integer>();
		li.add(34);////1024
		li.add(200);//1025
		li.add(180);//1026
		li.add(500);
		li.add(500);
		li.add(500);
		li.add(500);
		
		
		for(Integer x:li)
		{
			System.out.println(x);
		}
		
		System.out.println("##########################################");
		
		Iterator itr=li.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		
		
		
		
		
		
		
		

	}

}
