package CollectionsEx;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyOFString {

	public static void main(String[] args) {
		
		String str="Tip Tap toe tip tip tap";
		
		str=str.toLowerCase();
		
		String []s1= str.split(" ");
		
		Map<String,Integer> mp=new LinkedHashMap<String,Integer>();
		
		for(String x:s1)
		{
			if(mp.containsKey(x))
			{
				mp.put(x, (mp.get(x)+1));
			}
			else
			{
				mp.put(x,1);
			}
		}
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.println(x.getKey()+"  "+x.getValue());
		}
		
		int maxFreq=0;
		int minFreq=99999;
		
		String maxElement="",minElement="";
		
		
		for(Map.Entry<String,Integer> x:mp.entrySet() )
		{
			int freq=x.getValue();//
			String element=x.getKey();//
			if(freq>maxFreq)///
			{
				maxFreq=freq;//
				maxElement=element;//
				
			}
			
			if(freq<minFreq)//
			{
				minFreq=freq;///
				minElement=element;///
				
			}
			
		}
		
		
		System.out.println("MaximumFrequency is "+maxElement  +" -> "+maxFreq);
		System.out.println("MinimumFrequency is "+minElement  +" -> "+minFreq);
		
		
		
		

	}

}
