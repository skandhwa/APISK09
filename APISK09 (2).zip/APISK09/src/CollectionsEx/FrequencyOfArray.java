package CollectionsEx;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyOfArray {

	public static void main(String[] args) {
		
		int []a= {10,20,10,20,10,30};
		Map<Integer,Integer> mp=new LinkedHashMap<Integer,Integer>();
		for(Integer x:a)
		{
			if(mp.containsKey(x))
			{
				mp.put(x,(mp.get(x)+1));///mp.put(10,1+1)//mp.put(10,2)
			}
			else
			{
				mp.put(x, 1);
			}
		}
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.println(x.getKey()+"  "+x.getValue());
		}
		
		int maxFreq=0;
		int minFreq=99999;
		
		int maxElement=0,minElement=0;
		
		
		for(Map.Entry<Integer,Integer> x:mp.entrySet() )
		{
			int freq=x.getValue();///freq=3//freq=2//freq=1
			int element=x.getKey();//element=10///element=20//element=30
			if(freq>maxFreq)///1>3
			{
				maxFreq=freq;//maxFreq=3
				maxElement=element;//maxElement=10
				
			}
			
			if(freq<minFreq)//
			{
				minFreq=freq;///
				minElement=element;///
				
			}
			
		}
		
		
		System.out.println("MaximumFrequency is "+maxElement  +" -> "+maxFreq);
		System.out.println("MinimumFrequency is "+minElement  +" -> "+minFreq);
		
		
		

	}

}
