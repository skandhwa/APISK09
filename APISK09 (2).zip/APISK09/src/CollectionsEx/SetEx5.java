package CollectionsEx;

import java.util.LinkedHashSet;
import java.util.Set;

public class SetEx5 {

	public static void main(String[] args) {
		
		

		Set<String> s1=new LinkedHashSet<String>();
		s1.add("apple");
		s1.add("banana");
		s1.add("mango");
		s1.add("orange");
		
		
		Set<String> s2=new LinkedHashSet<String>();
		//s2.add("kiwi");
		s2.add("banana");
	//	s2.add("melon");
		s2.add("orange");
		
	boolean flag=	s1.containsAll(s2);
	
	System.out.println(flag);
		
		//System.out.println(s1);
	
	

	}

}
