package CollectionsEx;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArrytoArrayList {

	public static void main(String[] args) {
		
		int []a= {1,4,5,7,8};
		
		List<Integer> li=new ArrayList<Integer>();
		
		for(int x:a)
		{
			li.add(x);
		}
		
		System.out.println(li);
		
		List<Integer> li1 = new ArrayList<>(Arrays.asList(1, 2, 3, 4));
		
		
		
		

	}

}
