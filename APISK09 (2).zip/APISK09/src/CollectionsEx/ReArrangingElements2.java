package CollectionsEx;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ReArrangingElements2 {

	public static void main(String[] args) {
		
		int []a= {-1,0,3,2,0,0,1,0};
		
		List<Integer> li1=new ArrayList<Integer>();
		List<Integer> li2=new ArrayList<Integer>();
		
		for(Integer x:a)
		{
			if(x!=0)
			{
				li1.add(x);
				Collections.sort(li1);
			}
			else
			{
				li2.add(x);
			}
		}
		
		li1.addAll(li2);
		
		
		
		
		
		

	}

}
