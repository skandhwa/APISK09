package CollectionsEx;

import java.util.HashMap;
import java.util.Map;

public class MapEx4 {

	public static void main(String[] args) {
		
		
		Map<Integer,String> mp=new HashMap<Integer,String>();
		mp.put(1,"orange");
		mp.put(2,"apple");
		mp.put(3,"kiwi");
		mp.put(4,"melon");
		
		System.out.println(mp);
		
		
		Map<Integer,String> mp2=new HashMap<Integer,String>();
		mp2.put(1,"guava");
		mp2.put(2,"pomegranate");
		mp2.put(6,"banana");
		mp2.put(7,"mango");
		
		mp.putAll(mp2);
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"  ");
			System.out.println(x.getValue());
		}
		
		
		mp.remove(2);
		
	boolean flag4=	mp.equals(mp2);
	
	System.out.println("Are two maps equal  "+flag4);
		
		
		
		System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"  ");
			System.out.println(x.getValue());
		}
		
		mp.clear();
		
	boolean flag3=	mp.isEmpty();
	
	System.out.println("Is the map empty "+flag3);
	
	
		
		
		
		
		
		
		
		

	}

}
