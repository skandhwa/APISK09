package CollectionsEx;

import java.util.LinkedList;
import java.util.List;

public class LinkedListEx {

	public static void main(String[] args) {
		
		List<Integer> li=new LinkedList<Integer>();
		li.add(56);
		
		li.add(16);
		li.add(26);
		li.add(96);
		
		for(Integer x:li)
		{
			System.out.println(x);
		}
		
		
		
		
		
		

	}

}
