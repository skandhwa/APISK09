package CollectionsEx;

import java.util.TreeSet;

public class TreeSetEx1 {

	public static void main(String[] args) {
		
		TreeSet<Integer> s1=new TreeSet<Integer>();
		s1.add(22);
		s1.add(12);
		s1.add(56);
		s1.add(42);
		
		System.out.println(s1.descendingSet());
		
		
		
		
		
		
		

	}

}
