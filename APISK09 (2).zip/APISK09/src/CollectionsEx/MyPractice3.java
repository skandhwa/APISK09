package CollectionsEx;

import java.util.ArrayList;
import java.util.List;

public class MyPractice3 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("Orange");
		li.add("Mango");
		li.add("Apple");
		li.add("Banana");
		
		
		List<String> li2=new ArrayList<String>();
		li2.add("Kiwi");
		li2.add("Pineapple");
		li2.add("Apple");
		li2.add("Banana");
		
		
		
//		li.addAll(li2);
//		
//		System.out.println(li);
		
//	boolean flag=	li.containsAll(li2);
//	
//	System.out.println(flag);
//		
//		li2.removeAll(li);
//		
//		System.out.println(li2);
		
		li.retainAll(li2);
		
		System.out.println(li);
		
	boolean flag2=	li.equals(li2);
	System.out.println(flag2);
		
		
		
	
	
		
		
		
		
		
		

	}

}
