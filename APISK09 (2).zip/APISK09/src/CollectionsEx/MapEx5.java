package CollectionsEx;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class MapEx5 {

	public static void main(String[] args) {
		

		Map<Integer,String> mp=new LinkedHashMap<Integer,String>();
		mp.put(19,"orange");
		mp.put(12,"apple");
		mp.put(13,"kiwi");
		mp.put(14,"melon");
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"  ");
			System.out.println(x.getValue());
		}
		
	}

}
