package CollectionsEx;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class MapEx1 {

	public static void main(String[] args) {
		
		
		Map<Object,Object> mp=new HashMap<Object,Object>();
		mp.put(1234, "Saurabh");
		mp.put(1234, "Gaurabh");
		mp.put('A',true);
		mp.put('A',false);
		mp.put(23.44f,'D');
		mp.put(null,'F');
		mp.put(null,'G');
		mp.put(null,'H');
		mp.put('x',null);
		mp.put('y',null);
		
		
		System.out.println(mp);
		
		
		

	}

}
