package CollectionsEx;

import java.util.ArrayList;
import java.util.List;

public class MyPractice5 {

	public static void main(String[] args) {
		
		List<Object> li=new ArrayList<Object>();
		li.add(123);
		li.add("abcd");
		li.add('A');
		li.add(true);
		
	Object[]arr=	li.toArray();
	
	for(Object x:arr)
	{
		System.out.println(x);
	}
		
		
		
		
		
		

	}

}
