package CollectionsEx;

import java.util.ArrayList;
import java.util.List;

public class MyPractice4 {

	public static void main(String[] args) {
		
		List<Object> li=new ArrayList<Object>();
		li.add(123);
		li.add("abcd");
		li.add('A');
		li.add(true);
		
	Object y=	li.get(3);
	
	System.out.println("Element at index 3 is  "+y);
	
	li.set(2,"Harry");
	
	System.out.println(li);
		
		
		
		for(Object x:li)
		{
			System.out.println(x);
		}
		
		li.remove(2);
		
		System.out.println("After removing");
		
		System.out.println(li);
		
		li.remove(true);
		
		System.out.println(li);
		
		
		
		
		

	}

}
