package CollectionsEx;

import java.util.HashMap;
import java.util.Map;

public class MapEx2 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new HashMap<Integer,String>();
		mp.put(1,"orange");
		mp.put(2,"apple");
		mp.put(3,"kiwi");
		mp.put(4,"melon");
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"  ");
			System.out.println(x.getValue());
		}
		
		

	}

}
