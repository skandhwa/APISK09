package CollectionsEx;

import java.util.ArrayList;
import java.util.List;

public class ReArrangingElements {

	public static void main(String[] args) {
		
		char []ch= {'B','G','G','B','B','G'};
		
		List<Character> li1=new ArrayList<Character>();
		List<Character> li2=new ArrayList<Character>();
		
		for(char x:ch)
		{
			if(x=='G')
			{
				li1.add(x);
			}
			else
			{
				li2.add(x);
			}
		}
		
		li1.addAll(li2);
		
		Object[] arr= li1.toArray();
		
		for(Object y:arr)
		{
			System.out.print(y+" ");
		}
		
		
		
		
		
		
		

	}

}
