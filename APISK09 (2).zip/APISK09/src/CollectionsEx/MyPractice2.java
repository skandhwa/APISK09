package CollectionsEx;

import java.util.ArrayList;
import java.util.List;

public class MyPractice2 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("Orange");
		li.add("Mango");
		li.add("Apple");
		li.add("Banana");
		
	boolean flag=	li.contains("kiwi");
	
	System.out.println("Does the list contains Orange "+flag);
	
	li.clear();
	
	System.out.println(li);
	
	boolean flag2=li.isEmpty();
	
	System.out.println("Is the list empty "+flag2);
		
		
		
		
	}

}
