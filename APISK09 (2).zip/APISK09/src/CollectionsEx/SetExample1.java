package CollectionsEx;

import java.util.HashSet;
import java.util.Set;

public class SetExample1 {

	public static void main(String[] args) {
		
		
		Set<Integer> s =new HashSet<Integer>();
		s.add(34);
		s.add(200);
		s.add(180);
		s.add(500);
		s.add(null);
		s.add(null);
		
		
		
		for(Integer x:s)
		{
			System.out.println(x);
		}

	}

}
