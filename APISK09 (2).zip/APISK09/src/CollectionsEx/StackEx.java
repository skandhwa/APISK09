package CollectionsEx;

import java.util.Stack;

public class StackEx {

	public static void main(String[] args) {
		
		Stack<Integer> s=new Stack<Integer>();
		s.push(34);
		s.push(67);
		s.push(99);
		s.push(78);
		System.out.println(s);
		
		s.pop();
		
		System.out.println(s);
		
		
		
		
	}

}
