package PayloadData;

public class Payload {
	
	
	public static String addEmployeeDetails(String name,String job)
	{
		String empDetails="{\r\n"
				+ "    \"name\": \""+name+"\",\r\n"
				+ "    \"job\": \""+job+ "\"\r\n"
				+ "}";  
		
		return empDetails;
	}
	
	
	public static String addBook(String isbn,String aisle)
	{
		String bookDetails ="{\r\n"
				+ "\r\n"
				+ "\"name\":\"Learn Appium Automation with Java\",\r\n"
				+ "\"isbn\":\""+isbn+"\",\r\n"
				+ "\"aisle\":\""+aisle+"\",\r\n"
				+ "\"author\":\"John foe\"\r\n"
				+ "}\r\n"
				+ "";
		
		return bookDetails;
	}
	
	
	public static String addBook1(String name,String isbn,String aisle)
	{
		String bookDetails ="{\r\n"
				+ "\r\n"
				+ "\"name\":\""+name+"\",\r\n"
				+ "\"isbn\":\""+isbn+"\",\r\n"
				+ "\"aisle\":\""+aisle+"\",\r\n"
				+ "\"author\":\"John foe\"\r\n"
				+ "}\r\n"
				+ "";
		
		return bookDetails;
	}
	
	
	

}
